export const actionTypes = {
    SET_SEARCH_TERM :'SET_SEARCH_TERM',
    POST_PAYMENT : 'POST_PAYEMENT',
    //PAYMENT_SUCCESSFULE:'PAYMENT_SUCCESSFULE',
     INITIAL_STATE :{
        payments : [],
        
    },
} 


