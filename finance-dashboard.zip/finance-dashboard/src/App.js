

import 'bootstrap/dist/css/bootstrap.min.css';
import HomeComponent from './Components/HomeComponent';

function App() {
  return (
    <div className="App">
     <HomeComponent></HomeComponent>
    </div>
  );
}

export default App;
