export default {
  server: {
    port: 8080,
  },
};
